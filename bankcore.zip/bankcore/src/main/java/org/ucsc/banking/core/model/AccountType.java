package org.ucsc.banking.core.model;

public interface AccountType {

	int getAccountType();
	
	String getAccountTypeName();
	
}
